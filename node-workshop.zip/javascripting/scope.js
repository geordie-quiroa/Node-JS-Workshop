var a = 1, b = 2, c = 3;

(function firstFunction(){
    var b = 5, c = 6;

    (function secondFunction(){
        var b = 8;

        (function thirdFunction(){
            var a = 7, c = 9;

            (function fourthFunction(){
                var a = 1, c = 8;

            })();
        })();
        console.log("a: "+a+", b: "+b+", c: "+c);
    })();
})();

var f = new Date();
var fs = require('fs');
var path = require('path');
var nombreArchivo = path.basename(__filename);
fs.appendFile('logDeTasksFinalizados.txt', '\n'+"Geordie Quiroa - Terminé la parte <" + nombreArchivo + "> de javascripting el >> " + f, function (err) {
    if (err) throw err;
    });