function math(one, two, three){
    return two*three + one;
};

console.log(math(53,61,67));


var f = new Date();
var fs = require('fs');
var path = require('path');
var nombreArchivo = path.basename(__filename);
fs.appendFile('logDeTasksFinalizados.txt', '\n'+"Geordie Quiroa - Terminé la parte <" + nombreArchivo + "> de javascripting el >> " + f, function (err) {
    if (err) throw err;
    });