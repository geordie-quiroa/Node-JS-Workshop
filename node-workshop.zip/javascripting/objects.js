var pizza = {
    toppings:['cheese', 'sauce', 'pepperoni'],
    crust: 'deep dish',
    serves: 2
};

console.log(pizza)


var f = new Date();
var fs = require('fs');
var path = require('path');
var nombreArchivo = path.basename(__filename);
fs.appendFile('logDeTasksFinalizados.txt', '\n'+"Geordie Quiroa - Terminé la parte <" + nombreArchivo + "> de javascripting el >> " + f, function (err) {
    if (err) throw err;
    });