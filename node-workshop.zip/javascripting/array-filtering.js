var numbers = [1,2,3,4,5,6,7,8,9,10];
var filtered = numbers.filter(function numerosPares(valor){
    return valor %2===0;
});
console.log(filtered)

var f = new Date();
var fs = require('fs');
var path = require('path');
var nombreArchivo = path.basename(__filename);
fs.appendFile('logDeTasksFinalizados.txt', '\n'+"Geordie Quiroa - Terminé la parte <" + nombreArchivo + "> de javascripting el >> " + f, function (err) {
    if (err) throw err;
    });