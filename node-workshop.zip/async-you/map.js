var http = require('http');
var async = require('async');

async.map(process.argv.slice(2), (url, terminado)=>{
    var strings = '';
    http.get(url, (response)=>{
        response.on('data', (volData)=>{
            strings += volData.toString();
        });
        response.on('end', ()=>{
            return terminado(null, strings);
        });
    });
}, function terminado(err, resultados){
    if (err) return console.error(err);
    console.log(resultados);
});
var f = new Date();
var fs = require('fs');
var path = require('path');
var nombreArchivo = path.basename(__filename);
fs.appendFile('logDeTasksFinalizados.txt', '\n'+"Geordie Quiroa - Terminé la parte <" + nombreArchivo + "> de async-you el >> " + f, function (err) {
    if (err) throw err;
    });