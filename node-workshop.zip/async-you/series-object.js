var http = require('http');
var async = require('async');
async.series({
    requestOne: (terminado)=>{
        visitURL(process.argv[2], terminado);
    },
    requestTwo: (terminado)=>{
        visitURL(process.argv[3], terminado);
    }
}, function terminado(err, resultados){
    if (err) return console.error(err);
    console.log(resultados);
});

function visitURL(url, terminado){
    var strings = '';
    http.get(url, (response)=>{
        response.on('data', (volData)=>{
            strings+= volData.toString();
        });
        response.on('end', (volData)=>{
            terminado(null, strings);
        });
    }).on('error', (err)=>{
        terminado(err);
    });
};
var f = new Date();
var fs = require('fs');
var path = require('path');
var nombreArchivo = path.basename(__filename);
fs.appendFile('logDeTasksFinalizados.txt', '\n'+"Geordie Quiroa - Terminé la parte <" + nombreArchivo + "> de async-you el >> " + f, function (err) {
    if (err) throw err;
    });