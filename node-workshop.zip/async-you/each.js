var http = require('http');
var async = require('async');

async.each(process.argv[2].slice(2), (param, terminado)=>{
    http.get(param, (response)=> {
        response.on('data', (volData)=>{});
        response.on('end', ()=>{
            terminado(null);
        });
    }).on('error', (err)=>{
        terminado(err);
    });
}, (err)=>{
    if (err) console.error(err);
});

var f = new Date();
var fs = require('fs');
var path = require('path');
var nombreArchivo = path.basename(__filename);
fs.appendFile('logDeTasksFinalizados.txt', '\n'+"Geordie Quiroa - Terminé la parte <" + nombreArchivo + "> de async-you el >> " + f, function (err) {
    if (err) throw err;
    });