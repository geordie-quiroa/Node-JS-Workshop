var http = require('http');
var async = require('async');
var f = new Date();
var fs = require('fs');
var path = require('path');
var nombreArchivo = path.basename(__filename);
fs.appendFile('logDeTasksFinalizados.txt', '\n'+"Geordie Quiroa - Terminé la parte <" + nombreArchivo + "> de async-you el >> " + f, function (err) {
    if (err) throw err;
    });
    
async.reduce(['one', 'two', 'three'],0, (tmp, val, terminado)=>{
    var strings = '';
    http.get(process.argv[2]+"?number="+val, (response)=>{
        response.on('data', (volData)=>{
            strings+=volData.toString();
        });
        response.on('end', ()=>{
            terminado(null, tmp+Number(strings));
        });
    }).on('error', terminado);
}, function terminado(err,resultados){
    if (err) return console.log(err);
    console.log(resultados);
});
