
var fs = require('fs');
var http = require('http');
var async = require('async');

async.waterfall([
    (terminado) =>{
        fs.readFile(process.argv[2], (err,data)=>{
            if (err) return terminado(err);
            terminado(null,data);
        });
    },
    (data, terminado)=>{
        var string = '';
        http.get(data.toString().trimRight(), (response)=>{
            response.on('data', (volData)=>{
                string += volData.toString();
            });
            response.on('end', (volData)=>{
                terminado(null, string);
            });
        }).on('error', (err)=>{
            terminado(err);
        });
    }
], function terminado(err, resultados){
    if (err) return console.error(err);
    console.log(resultados);
});

var f = new Date();
var path = require('path');
var nombreArchivo = path.basename(__filename);
fs.appendFile('logDeTasksFinalizados.txt', '\n'+"Geordie Quiroa - Terminé la parte <" + nombreArchivo + "> de async-you el >> " + f, function (err) {
    if (err) throw err;
    });