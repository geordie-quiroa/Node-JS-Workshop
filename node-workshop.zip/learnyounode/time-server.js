var net = require('net');
var port = process.argv[2];

var f = new Date();
var mesCorrecto = function monthCorrection(month){
    if (month<9){
        return "0" + (month + 1).toString();
    }
    else{
        return (mes+1).toString();
    }
};
var formatted = f.getFullYear() + "-" + mesCorrecto(f.getMonth())  + "-" + f.getDate() + " " + f.getHours() + ":" + f.getMinutes() ;

var server = net.createServer(socket => {
  socket.write(formatted);
  socket.end("\n");

}).on('error', err => {
  // handle errors here
  throw err;
});


server.listen(port);
var fs = require('fs');
var path = require('path');
var nombreArchivo = path.basename(__filename);
fs.appendFile('logDeTasksFinalizados.txt', '\n'+"Geordie Quiroa - Terminé la parte <" + nombreArchivo + "> de learnyounode el >> " + f, function (err) {
    if (err) throw err;
    });
