var fs = require('fs');

function callback (err, data){
    if (err) return console.log(err)
    var arreglo = data.split('\n');
    //console.log(data);
    console.log(arreglo.length-1)
    var f = new Date();
    var path = require('path');
    var nombreArchivo = path.basename(__filename);
    fs.appendFile('logDeTasksFinalizados.txt', '\n'+"Geordie Quiroa - Terminé la parte <" + nombreArchivo + "> de learnyounode el >> " + f, function (err) {
        if (err) throw err;
        });
};

function readFile(){
    var read = process.argv[2];
    var readFile = read.toString();
    var file = fs.readFile(readFile, 'utf-8', callback)
}
readFile();