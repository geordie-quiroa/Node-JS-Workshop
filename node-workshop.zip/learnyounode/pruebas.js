var f = new Date();
var anio = f.getFullYear();
var mes = f.getMonth()+1;
var dia = f.getDate();
console.log(anio +'-'+ mes +'-'+ dia);