console.log("HELLO WORLD");
var f = new Date();
var fs = require('fs');
var path = require('path');
var nombreArchivo = path.basename(__filename);
fs.appendFile('logDeTasksFinalizados.txt', '\n'+"Geordie Quiroa - Terminé la parte <" + nombreArchivo + "> de learnyounode el >> " + f, function (err) {
    if (err) throw err;
    });