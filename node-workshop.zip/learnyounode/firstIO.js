var fs= require('fs');

var readF = fs.readFileSync(process.argv[2]);

var file = readF.toString()
//console.log(file)
var totalLineas = file.split('\n');
console.log(totalLineas.length -1);

var f = new Date();
var path = require('path');
var nombreArchivo = path.basename(__filename);
fs.appendFileSync('logDeTasksFinalizados.txt', '\n'+"Geordie Quiroa - Terminé la parte <" + nombreArchivo + "> de javascripting el >> " + f);

