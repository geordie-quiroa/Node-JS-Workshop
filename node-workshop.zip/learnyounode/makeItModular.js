var m = require('./makeItModular2.js');

var callbackMain = function (err, filteredArray) {
    if (err) throw err;
    filteredArray.forEach(function (file) {
        console.log(file);
    });
    var f = new Date();
    var nombreArchivo = route.basename(__filename);
    fs.appendFile('logDeTasksFinalizados.txt', '\n'+"Geordie Quiroa - Terminé la parte <" + nombreArchivo + "> de learnyounode el >> " + f, function (err) {
        if (err) throw err;
        });
};

m(process.argv[2], process.argv[3], callbackMain);