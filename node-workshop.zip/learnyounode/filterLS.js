var fs = require('fs');
var route = require('path');
var path2read = process.argv[2];
var path = path2read.toString();
var extension = process.argv[3];
var ext = "." + extension.toString();

function callback(err, data){
    var f = new Date();
    if (err) return console.error(err);
    //console.log(data);
    data.forEach(file => {
        if (route.extname(file)=== ext){
            console.log(file)
        }
    });
    var f = new Date();
    var nombreArchivo = route.basename(__filename);
    fs.appendFile('logDeTasksFinalizados.txt', '\n'+"Geordie Quiroa - Terminé la parte <" + nombreArchivo + "> de learnyounode el >> " + f, function (err) {
        if (err) throw err;
        });
}

function listDirs(){
    fs.readdir(path, 'utf-8', callback)
    //console.log(path2read)
    //console.log(extension)
};
listDirs()