var http = require('http');
var map = require('through2-map');
var portNumber = process.argv[2];

http.createServer(function (req, res) {
    if (req.method === 'POST') {
    req.pipe(map(function (chunk) {
    return chunk.toString().toUpperCase();
    })).pipe(res);
    }
   }).listen(portNumber);
var f = new Date();
var fs = require('fs');
var path = require('path');
var nombreArchivo = path.basename(__filename);
fs.appendFile('logDeTasksFinalizados.txt', '\n'+"Geordie Quiroa - Terminé la parte <" + nombreArchivo + "> de learnyounode el >> " + f, function (err) {
    if (err) throw err;
    });