var http = require('http');
var resultados = '';
http.get(process.argv[2], (response)=>{
	response.setEncoding('utf8');
	response.on('data', (data)=>{
		resultados+=data.toString();
	});
	response.on('error', (e)=>{
	    console.log(e);
	});
	response.on('end',()=>{
		console.log(resultados.length);
		console.log(resultados);
		resultados='';
	});
});
var f = new Date();
var fs = require('fs');
var path = require('path');
var nombreArchivo = path.basename(__filename);
fs.appendFile('logDeTasksFinalizados.txt', '\n'+"Geordie Quiroa - Terminé la parte <" + nombreArchivo + "> de learnyounode el >> " + f, function (err) {
    if (err) throw err;
    });
