var http = require('http');
var urls = [process.argv[2], process.argv[3], process.argv[4]];
var resultados = [];
var contador = 0;

function consultar(url, urlPos) {
	http.get(url, (response) =>{
		data2String = "";
		response.setEncoding('utf8');
		response.on('data', function addData(data){
	        data2String = data2String.concat(data);
	    });
	    response.on('end', function guardarData(){
	        resultados[urlPos] = data2String;
	        contador++;
	        if(contador == 3) {
				for (i = 0; i < resultados.length; i++) {
			        console.log(resultados[i]);
                };
                var f = new Date();
                var fs = require('fs');
                var path = require('path');
                var nombreArchivo = path.basename(__filename);
                fs.appendFile('logDeTasksFinalizados.txt', '\n'+"Geordie Quiroa - Terminé la parte <" + nombreArchivo + "> de learnyounode el >> " + f, function (err) {
                    if (err) throw err;
                    });
			};
	    });
	});
};

for(i = 0; i < 3; i++) {
	consultar(urls[i], i);
}