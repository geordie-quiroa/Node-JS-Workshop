var arreglo = process.argv;
var total = 0;
for (var i=2; i<=(arreglo.length-1); i++){
    total+=Number(arreglo[i]);
  }
console.log(total);

var f = new Date();
var fs = require('fs');
var path = require('path');
var nombreArchivo = path.basename(__filename);
fs.appendFile('logDeTasksFinalizados.txt', '\n'+"Geordie Quiroa - Terminé la parte <" + nombreArchivo + "> de learnyounode el >> " + f, function (err) {
    if (err) throw err;
    });
    