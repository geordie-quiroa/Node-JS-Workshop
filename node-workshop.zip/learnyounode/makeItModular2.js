var fs = require('fs');
var route= require('path');

module.exports = function listDirs(path, extension, callback){
    fs.readdir(path, 'utf-8', function(err, data){
        if (err){
             return callback(err);}
        else{
            var finalValues = [];
            var ext="."+extension;
            data.forEach(file => {
                if (route.extname(file)=== ext){
                    //console.log(file)
                    finalValues.push(file);
                };
            });
        };
    return callback(null, finalValues);
    });
};